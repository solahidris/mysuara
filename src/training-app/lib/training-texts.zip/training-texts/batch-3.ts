export const batch3Stories = [
  {
    id: 97,
    title: "Cerita 4 — Organisasi & Sumber Manusia (Bahagian 4)",
    content: "Kewangan dikawal akauntan; operasi dibantu juruteknik; reka bentuk diurusjuruteradan pereka bentuk; hala tuju diperkemas perunding, penyelaras, dan penyelia tapakyang menyelia kontraktorserta pembekal."
  },
  {
    id: 98,
    title: "Cerita 5 — Pelanggan & Pasaran (Bahagian 1)",
    content: "Produk baharu dilancar kepada pelanggan dan pengguna, menarik minat pembelidan penjual."
  },
  {
    id: 99,
    title: "Cerita 5 — Pelanggan & Pasaran (Bahagian 2)",
    content: "Pasukan pemasaranmerancang promosi, menyiapkan iklan, membina jenamauntuk produk dan perkhidmatan."
  },
  {
    id: 100,
    title: "Cerita 5 — Pelanggan & Pasaran (Bahagian 3)",
    content: "Bahagian servis pelanggan mengurus jaminan, menyelesaikan aduan,memproses pulangan, dan menyediakan sokongan teknikalyang responsif."
  },
  {
    id: 101,
    title: "Cerita 6 — Infrastruktur Digital Harian (Bahagian 1)",
    content: "Operasi bergantung pada sistem yang menyepadukan perisian dan perkakasandi atas rangkaian yang stabil."
  },
  {
    id: 102,
    title: "Cerita 6 — Infrastruktur Digital Harian (Bahagian 2)",
    content: "Pelayanmenyimpan pangkalan data; transaksi melalui internet dan laman webserta saluran media sosial pada platforminteraktif."
  },
  {
    id: 103,
    title: "Cerita 6 — Infrastruktur Digital Harian (Bahagian 3)",
    content: "Aplikasi mudah alih di telefon pintar, komputer riba, dan tablet memudahkankerja."
  },
  {
    id: 104,
    title: "Cerita 6 — Infrastruktur Digital Harian (Bahagian 4)",
    content: "Peranti seperti pengimbas, pencetak, kamera, mikrofon, dan fon telingadisambung wayarles melalui bluetooth."
  },
  {
    id: 105,
    title: "Cerita 6 — Infrastruktur Digital Harian (Bahagian 5)",
    content: "Proses sambungan, muat turun, muat naik, log masuk, dan kata laluan diurusrapi bagi pengalaman lancar."
  },
  {
    id: 106,
    title: "Cerita 7 — Keselamatan & Privasi (Bahagian 1)",
    content: "Pasukan IT menegakkan keselamatan siber, melindungi privasi data danmaklumat peribadi."
  },
  {
    id: 107,
    title: "Cerita 7 — Keselamatan & Privasi (Bahagian 2)",
    content: "Mereka mengaktifkan penyulitan, menjadual sandaran ke awan digital, danmengoptimumkan storan serta pemprosesan."
  },
  {
    id: 108,
    title: "Cerita 7 — Keselamatan & Privasi (Bahagian 3)",
    content: "Insiden diuji melalui simulasi pencerobohan untuk menambah baik kawalanakses dan respons kecemasan."
  },
  {
    id: 109,
    title: "Cerita 8 — Kecerdasan Buatan di Tempat Kerja (Bahagian 1)",
    content: "Algoritma algoritma dipilih untuk projek kecerdasan buatan; modul pembelajaranmesin memacu automasi dan menyokong sel robot robotik di kilang."
  },
  {
    id: 110,
    title: "Cerita 8 — Kecerdasan Buatan di Tempat Kerja (Bahagian 2)",
    content: "Melalui inovasi digital, organisasi membina keupayaan analitik data danvisualisasi data untuk memantau KPI."
  },
  {
    id: 111,
    title: "Cerita 8 — Kecerdasan Buatan di Tempat Kerja (Bahagian 3)",
    content: "Jurutera menulis pengaturcaraan dalam kod dan skrip yang serasi dengan sistemoperasi; integrasi ke aplikasi web diselaraskan bagi menyokong pembangunan perisianberterusan."
  },
  {
    id: 112,
    title: "Cerita 9 — Dari Bengkel Kod ke Pasaran (Bahagian 1)",
    content: "Sebuah skuad lincah menukar prototaip kepada produk."
  },
  {
    id: 113,
    title: "Cerita 9 — Dari Bengkel Kod ke Pasaran (Bahagian 2)",
    content: "Mereka menggabungkan prinsip reka bentuk, ujian pengguna, dan tadbir datapada pangkalan data teras."
  },
  {
    id: 114,
    title: "Cerita 9 — Dari Bengkel Kod ke Pasaran (Bahagian 3)",
    content: "Setiap sprint didokumenkan, isu ditutup dengan fakta, bukti, serta metrik yangjelas."
  },
  {
    id: 115,
    title: "Cerita 9 — Dari Bengkel Kod ke Pasaran (Bahagian 4)",
    content: "Aplikasi dilancarkan, pelanggan mencuba, sokongan memantau aduan; jikaperlu, pasukan kembali ke fasa pembaikan untuk memastikan peningkatan kualitiberterusan."
  },
  {
    id: 116,
    title: "Cerita 10 — Penutup Projek & Pembelajaran (Bahagian 1)",
    content: "Pada akhir tahun, pasukan menulis laporan impak."
  },
  {
    id: 117,
    title: "Cerita 10 — Penutup Projek & Pembelajaran (Bahagian 2)",
    content: "Mereka menilai kejayaan dan kelemahan, menyusun ringkasan, rujukan, danbibliografi; pembentangan dibuat kepada lembaga."
  },
  {
    id: 118,
    title: "Cerita 10 — Penutup Projek & Pembelajaran (Bahagian 3)",
    content: "Refleksi menegaskan bahawa kegagalan awal ialah guru yang memacukemajuan, bahawa inovasi berpaut pada etika dan akauntabiliti, dan bahawa ilmu hanyabermakna apabila disampaikan dengan jelas serta ditadbir dengan beramanah."
  },
  {
    id: 119,
    title: "Cerita 1 — Akaun & Utiliti Kediaman (Bahagian 1)",
    content: "Pusat komuniti membuka akaun pelanggan untuk memproses bantuan kewangandan bantuan kebajikan."
  },
  {
    id: 120,
    title: "Cerita 1 — Akaun & Utiliti Kediaman (Bahagian 2)",
    content: "Setiap permohonan bantuan disemak sehingga mendapat kelulusanpermohonan, lalu pengagihan dana direkod sebagai pelaporan kewangan."
  },
  {
    id: 121,
    title: "Cerita 1 — Akaun & Utiliti Kediaman (Bahagian 3)",
    content: "Penjaga dana menyemak penyata bank, baki akaun, dan transaksi elektroniktermasuk pindahan wang serta bayaran automatik untuk bil utiliti: air, elektrik, gas, internet,dan telefon."
  },
  {
    id: 122,
    title: "Cerita 1 — Akaun & Utiliti Kediaman (Bahagian 4)",
    content: "Di hartanah komuniti, cukai pintu, sewa rumah, dan penyelenggaraan diurus olehunit pengurusan harta yang berurusan dengan pemilik rumah dan penyewa mengikutperjanjian sewa; jika ingkar, notis pengosongan dikeluarkan tetapi deposit keselamatandipulangkan mengikut syarat."
  },
  {
    id: 123,
    title: "Cerita 1 — Akaun & Utiliti Kediaman (Bahagian 5)",
    content: "Serahan kunci rumah dilaksana untuk pangsapuri, kondominium, rumah teres,rumah pangsa, banglo, rumah kampung, malah rumah panjang di pedalaman."
  },
  {
    id: 124,
    title: "Cerita 2 — Komuniti & Nilai (Bahagian 1)",
    content: "Di sebuah komuniti rukun, struktur kejiranan dalam taman perumahan meriahdengan aktiviti di surau, masjid, gereja, kuil, dan tokong—semua rumah ibadat yangmencerminkan agama dan kepercayaan pelbagai kaum."
  },
  {
    id: 125,
    title: "Cerita 2 — Komuniti & Nilai (Bahagian 2)",
    content: "Program nilai menegakkan nilai moral, etika, dan akhlak, sambil memeliharabudaya, adat, tradisi, dan warisansetempat melalui kelas budi bahasa dan gotong-royongmingguanku."
  },
  {
    id: 126,
    title: "Cerita 3 — Bahasa & Seni (Bahagian 1)",
    content: "Kelab bahasa memupuk minat bahasa dan kesusasteraan melalui puisi, sajak,cerpen, novel, dan skrip drama untuk pementasan teater."
  },
  {
    id: 127,
    title: "Cerita 3 — Bahasa & Seni (Bahagian 2)",
    content: "Kelab muzik mengajarkan teori muzik, menggubah lagu, dan melatih nyanyian."
  },
  {
    id: 128,
    title: "Cerita 3 — Bahasa & Seni (Bahagian 3)",
    content: "Studio senimenempatkan lukisan, arca, dan latihan tarian; semuanya digabungdalam persembahan akhir semester yang menonjolkan kreativiti pelajar."
  },
  {
    id: 129,
    title: "Cerita 4 — Perayaan & Cuti Umum (Bahagian 1)",
    content: "Takwim festival memaklumkan sambutan dan perayaan seperti Hari RayaAidilfitri, Hari Raya Aidiladha, Tahun Baru Cina, Deepavali, Krismas, Gawai Dayak,Kaamatan, Thaipusam, Wesak, Maulidur Rasul, dan Tahun Baru."
  },
  {
    id: 130,
    title: "Cerita 4 — Perayaan & Cuti Umum (Bahagian 2)",
    content: "Juga diraikan Hari Kebangsaan, Hari Malaysia, Hari Merdeka, Hari Guru, HariPekerja, Hari Wanita, Hari Bapa, Hari Ibu, dan Hari Kanak-kanak sebagai Cuti Umum."
  },
  {
    id: 131,
    title: "Cerita 4 — Perayaan & Cuti Umum (Bahagian 3)",
    content: "Ada perarakan, sambutan rasmi, ucapan, doa, khutbah, majlis, dan jamuan yangmenyatukan warga tanpa mengira latar."
  },
  {
    id: 132,
    title: "Cerita 5 — Hidangan & Rumah Terbuka (Bahagian 1)",
    content: "Sempena sambutan keluarga dan rumah terbuka, tuan rumah menghidangmakanan tradisional."
  },
  {
    id: 133,
    title: "Cerita 5 — Hidangan & Rumah Terbuka (Bahagian 2)",
    content: "Di meja hidanganberderet lauk: nasi lemak, rendang, satay, laksa, roti canai;minuman teh tarik dan kopi ais; pencuci mulut cendol, ais kacang, dan kuih-muih."
  },
  {
    id: 134,
    title: "Cerita 5 — Hidangan & Rumah Terbuka (Bahagian 3)",
    content: "Rencah sambal dan belacan menaikkan selera."
  },
  {
    id: 135,
    title: "Cerita 5 — Hidangan & Rumah Terbuka (Bahagian 4)",
    content: "Jiran dan tetamu hadir dengan jemputan, membawa hadiah dan kad ucapan."
  },
  {
    id: 136,
    title: "Cerita 5 — Hidangan & Rumah Terbuka (Bahagian 5)",
    content: "Gambar kenangan dirakam melalui fotografi, video rakaman, dan siaranlangsung."
  },
  {
    id: 137,
    title: "Cerita 6 — Media Sosial & Keselamatan Siber (Bahagian 1)",
    content: "Selepas majlis, panitia memuat naik media sosial hantaran dengan kapsyen dantanda pagar; pengikut menekan suka, komen, dan kongsi melalui profil masing-masing danakaun media sosial rasmi."
  },
  {
    id: 138,
    title: "Cerita 6 — Media Sosial & Keselamatan Siber (Bahagian 2)",
    content: "Mereka menitikberatkan privasi, tetapan, dan keselamatan akaun dengan katalaluan kuat serta pengesahan dua faktor."
  },
  {
    id: 139,
    title: "Cerita 6 — Media Sosial & Keselamatan Siber (Bahagian 3)",
    content: "Amaran dikeluarkan tentang pautan dan pautan palsu, penipuan dalam talian,maklumat palsu, berita palsu, scam, dan pemalsuan identiti."
  },
  {
    id: 140,
    title: "Cerita 6 — Media Sosial & Keselamatan Siber (Bahagian 4)",
    content: "Pasukan IT memantau jenayah siber oleh penggodam, menapis perisian hasad,virus komputer, dan membaiki fail rosak akibat muat turun tidak sah."
  },
  {
    id: 141,
    title: "Cerita 6 — Media Sosial & Keselamatan Siber (Bahagian 5)",
    content: "Mereka juga mendidik komuniti tentang hak cipta, lesen perisian, paten, tandadagangan, reka bentuk industri, harta intelek, serta tindakan jika berlaku pelanggaran."
  },
  {
    id: 142,
    title: "Cerita 7 — Proses Mahkamah (Bahagian 1)",
    content: "Apabila berlaku fitnah atas talian, pengadu memfailkan saman di mahkamah."
  },
  {
    id: 143,
    title: "Cerita 7 — Proses Mahkamah (Bahagian 2)",
    content: "Dalam perbicaraan, pendakwa rayadan peguam bela berhujah, saksi memberiketerangan disokong bukti dokumentari dan laporan polis hasil siasatan."
  },
  {
    id: 144,
    title: "Cerita 7 — Proses Mahkamah (Bahagian 3)",
    content: "Mahkamah menilai dakwaan dan pertuduhan, seterusnya mengeluarkanpenghakiman dan keputusan hakim."
  }
]
