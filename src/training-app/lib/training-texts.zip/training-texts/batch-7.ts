export const batch7Stories = [
  {
    id: 289,
    title: "Cerita 10 — Menghubungkan Semua Benang Merah (Bahagian 2)",
    content: "Pasukan penganalisis pasaran dan penganalisis ekonomi menunjukkan impakCSR kepada komuniti, manakala pegawai hubungan awam dan wakil media mengaturnaratif kenyataan dasar."
  },
  {
    id: 290,
    title: "Cerita 10 — Menghubungkan Semua Benang Merah (Bahagian 3)",
    content: "HR mengumumkan promosi dalaman tambahan bagi bakat AI—jurutera AI, pakarAI, dan saintis data—serta anugerah anugerah prestasi yang disertai program kebajikankomuniti."
  },
  {
    id: 291,
    title: "Cerita 10 — Menghubungkan Semua Benang Merah (Bahagian 4)",
    content: "Dengan tadbir urus kukuh, transformasi digital, dan kelestarian yang nyata,organisasi menutup tahun dengan laporan tahunan yang menyatukan akauntabiliti, inovasi,dan empati."
  },
  {
    id: 292,
    title: "Cerita 1 — Patuh Jalan, Selamat Semua (Bahagian 1)",
    content: "Untuk menjaga keselamatan awam dan ketenteraman awam, polis meningkatkanrondaan keselamatan dan kawalan trafik."
  },
  {
    id: 293,
    title: "Cerita 1 — Patuh Jalan, Selamat Semua (Bahagian 2)",
    content: "Unit polis trafik bekerjasama dengan Jabatan Pengangkutan Jalan (JPJ) dalamoperasi bersepadu; saman trafik dikeluarkan ketika operasi keselamatan jalan dan kempenkeselamatan jalan raya."
  },
  {
    id: 294,
    title: "Cerita 1 — Patuh Jalan, Selamat Semua (Bahagian 3)",
    content: "Papan peringatan menekankan pemandu berhemah, had laju, serta pematuhanundang-undang; sesi kaunseling diberi kepada pesalah pelanggaran undang-undang yangmenerima denda kompaun."
  },
  {
    id: 295,
    title: "Cerita 2 — Dari Sekolah Memandu ke Jalan Raya (Bahagian 1)",
    content: "Calon memohon lesen memandu, lulus ujian memandu, bermula dengan lesensementara sebelum memperoleh lesen kompeten."
  },
  {
    id: 296,
    title: "Cerita 2 — Dari Sekolah Memandu ke Jalan Raya (Bahagian 2)",
    content: "Mereka menjalani ujian komputer JPJ, latihan memandu di sekolah memandu,dan proses pengujian kenderaan termasuk pemeriksaan PUSPAKOM."
  },
  {
    id: 297,
    title: "Cerita 2 — Dari Sekolah Memandu ke Jalan Raya (Bahagian 3)",
    content: "Syarat jalan meliputi cukai jalan dan insurans kenderaan; untuk kenderaankomersial seperti lori, van, bas sekolah, bas ekspres, teksi, serta e-hailing oleh pemanduGrab, standard keselamatan penumpang dipantau rapi."
  },
  {
    id: 298,
    title: "Cerita 3 — Transit Pintar Bandar (Bahagian 1)",
    content: "Kota memperluas sistem tambang tanpa tunai seperti MyRapid, Touch ‘n Go, dankad pengangkutan awam."
  },
  {
    id: 299,
    title: "Cerita 3 — Transit Pintar Bandar (Bahagian 2)",
    content: "Kecekapan meningkat di stesen MRT, sepanjang laluan LRT dan laluan monorel,serta perkhidmatan bas awammelalui integrasi pengangkutan dalam sistem transit pintar."
  },
  {
    id: 300,
    title: "Cerita 3 — Transit Pintar Bandar (Bahagian 3)",
    content: "Hasilnya, mobiliti bandar dan jaringan pengangkutan bertambah baik,mengurangkan kesesakan lalu lintas dengan pengurusan trafik dan sistem lampu isyaratdisokong kamera AES."
  },
  {
    id: 301,
    title: "Cerita 4 — Lebuh Raya Musim Perayaan (Bahagian 1)",
    content: "Di tol, kutipan tol di lebuh raya utama—PLUS, LPT, DASH, SUKE—dipermudahmelalui sistem RFID dan pembayaran tol elektronik, mewujudkan perjalanan lancar."
  },
  {
    id: 302,
    title: "Cerita 4 — Lebuh Raya Musim Perayaan (Bahagian 2)",
    content: "Ketika cuti perayaan, aliran trafik tinggi diurus melalui operasi khas raya dankempen balik kampung; pasukan memastikan keselamatan musim perayaan denganpemantauan polis, bantuan kecemasan, rondaan lebuh raya, dan trak tunda."
  },
  {
    id: 303,
    title: "Cerita 4 — Lebuh Raya Musim Perayaan (Bahagian 3)",
    content: "Setiap laporan kemalangandianalisis demi keselamatan pengguna jalan raya danpeningkatan kesedaran awam terhadap peranan pemandu bertanggungjawab."
  },
  {
    id: 304,
    title: "Cerita 5 — Kenderaan Sihat, Nyawa Selamat (Bahagian 1)",
    content: "Hari pemeriksaan bermula dengan pemeriksaan kenderaan: keadaan tayar,tahap minyak enjin, keberkesanan brek, serta lampu isyarat kenderaan."
  },
  {
    id: 305,
    title: "Cerita 5 — Kenderaan Sihat, Nyawa Selamat (Bahagian 2)",
    content: "Cermin diperiksa—cermin sisi, cermin pandang belakang—dan pengelapcermindiuji."
  },
  {
    id: 306,
    title: "Cerita 5 — Kenderaan Sihat, Nyawa Selamat (Bahagian 3)",
    content: "Di kabin, tali pinggang keledar dan beg udara diwajibkan; teknologi seperti sistembrek ABS, kawalan kestabilan, amaran jarak, kamera belakang, penderia parkir, dan sistembantuan pemandu mempertingkat keselamatan."
  },
  {
    id: 307,
    title: "Cerita 5 — Kenderaan Sihat, Nyawa Selamat (Bahagian 4)",
    content: "Menuju masa depan kereta pintar dan kenderaan autonomi, piawaiankeselamatan AI untuk teknologi pemanduan sendiri digubal selari dasar kenderaan masadepan dan agenda mobiliti pintar."
  },
  {
    id: 308,
    title: "Cerita 6 — EV untuk Mobiliti Hijau (Bahagian 1)",
    content: "Bandar melaksanakan pengangkutan elektrik dengan insentif cukai EV, membinapengecas awam dan jaringan pengecas."
  },
  {
    id: 309,
    title: "Cerita 6 — EV untuk Mobiliti Hijau (Bahagian 2)",
    content: "Pelaksanaan pelan mobiliti hijau menolak emisi, menyokong pengangkutanmampan, dan menyelaras keperluan penetapan tarif serta ruang parkir khusus EV."
  },
  {
    id: 310,
    title: "Cerita 7 — Tenaga untuk Negara (Bahagian 1)",
    content: "Kerangka dasar tenaga menjamin bekalan elektrik melalui Tenaga NasionalBerhad (TNB) dan grid nasional yang disokong pusat janakuasa."
  },
  {
    id: 311,
    title: "Cerita 7 — Tenaga untuk Negara (Bahagian 2)",
    content: "Campuran bahan api dipelbagaikan: tenaga hidroelektrik, tenaga solar, tenagaangin, tenaga biojisim, disertai storan tenaga berasaskan bateri litium dan pengecaspantas."
  },
  {
    id: 312,
    title: "Cerita 7 — Tenaga untuk Negara (Bahagian 3)",
    content: "Peralihan tenaga boleh diperbaharui sejajar dasar hijau negara, pelan tindakantenaga, penjimatan tenaga, dan kecekapan tenaga."
  },
  {
    id: 313,
    title: "Cerita 7 — Tenaga untuk Negara (Bahagian 4)",
    content: "Rakyat memantau penggunaan elektrik, bil elektrik, kadar tarif, serta subsidielektrik bagi penggunaan domestik, penggunaan komersial, dan sektor perindustrian."
  },
  {
    id: 314,
    title: "Cerita 7 — Tenaga untuk Negara (Bahagian 5)",
    content: "Bagi menyeimbangkan permintaan tenaga dan keseimbangan bekalan,pengurusan tenaga menilai pilihan tenaga nuklear dengan penekanan keselamatan nuklear;kajian tenaga alternatif, penyelidikan tenaga, dan inovasi tenaga bersih mengukuhkanekonomi tenaga, menarik pelaburan tenaga kepada syarikat tenaga dan agensi tenaga."
  },
  {
    id: 315,
    title: "Cerita 7 — Tenaga untuk Negara (Bahagian 6)",
    content: "Suruhanjaya Tenaga serta kementerian tenaga menjejak dasar tenaga bolehbaharu, sasaran tenaga hijau, laporan kemajuan tenaga, dan audit tenaga ke arahpengurangan karbon, neutraliti karbon, dan ekonomi rendah karbon dalam kerangka pelantindakan hijau dan pembangunan lestari."
  },
  {
    id: 316,
    title: "Cerita 8 — SDG: Ukur, Lapor, Tindak (Bahagian 1)",
    content: "Negara komited kepada Agenda 2030 dan Matlamat Pembangunan Mampan(SDG), diselaraskan melalui SDG Malaysia, pelaporan SDG, dan pemantauan kemajuanSDG."
  },
  {
    id: 317,
    title: "Cerita 8 — SDG: Ukur, Lapor, Tindak (Bahagian 2)",
    content: "Antara teras: kemiskinan sifar, tiada kelaparan, kesihatan baik, pendidikanberkualiti, kesamarataan gender, air bersih, tenaga bersih, pekerjaan baik, ekonomi inklusif,industri inovatif, bandar mampan, penggunaan bertanggungjawab, tindakan iklim, kehidupandi darat, kehidupan di laut, keamanan dan keadilan, serta perkongsian global."
  },
  {
    id: 318,
    title: "Cerita 8 — SDG: Ukur, Lapor, Tindak (Bahagian 3)",
    content: "Setiap tahun, laporan pembangunandan penilaian kemajuan merujuk indikatornasional berasaskan data pembangunan."
  },
  {
    id: 319,
    title: "Cerita 9 — Data untuk Dasar (Bahagian 1)",
    content: "Kementerian ekonomi bersama Unit Perancang Ekonomi (EPU) dan JabatanPerangkaan Malaysia (DOSM) menggunakan bancian penduduk, laporan statistik, indikatorsosial, serta indikator ekonomi untuk menilai indeks pembangunan manusia (IPM)."
  },
  {
    id: 320,
    title: "Cerita 9 — Data untuk Dasar (Bahagian 2)",
    content: "Mereka memantau kadar kemiskinan, pendapatan isi rumah, kelompok B40,M40, T20, tahap ketidaksamaan ekonomi, dan jurang pendapatan; dapatan ini memandureka bentuk intervensi yang lebih tepat sasaran."
  },
  {
    id: 321,
    title: "Cerita 10 — Jaringan Perlindungan Sosial (Bahagian 1)",
    content: "Kerajaan mengukuhkan jaringan sokongan melalui bantuan kewangan, skimsubsidi, dan skim perlindungan di bawah program bantuan rakyat."
  },
  {
    id: 322,
    title: "Cerita 10 — Jaringan Perlindungan Sosial (Bahagian 2)",
    content: "Inisiatif seperti STR dan bantuan tunai langsung membantu keluarga rentanmenampung kos sara hidup, sambil melengkapkan usaha tenaga hijau, pengangkutanselamat, dan pembangunan berasaskan data untuk kesejahteraan nasional yangmenyeluruh."
  },
  {
    id: 323,
    title: "Cerita 1 — Jaringan Bantuan & Perlindungan Sosial (Bahagian 1)",
    content: "Selepas banjir, kerajaan melancarkan bantuan khas kerajaan di samping bantuanbulanan untuk keluarga rentan."
  },
  {
    id: 324,
    title: "Cerita 1 — Jaringan Bantuan & Perlindungan Sosial (Bahagian 2)",
    content: "Sebuah pusat setempat menyelaras bantuan keluarga, bantuan pendidikan,bantuan perumahan, bantuan kesihatan, bantuan OKU, bantuan warga emas, bantuan ibutunggal, bantuan pelajar miskin, dan bantuan sara hidup."
  },
  {
    id: 325,
    title: "Cerita 1 — Jaringan Bantuan & Perlindungan Sosial (Bahagian 3)",
    content: "Bagi krisis mendadak, bantuan bencana diaktifkan melalui tabung kecemasanserta dana khas kerajaan."
  },
  {
    id: 326,
    title: "Cerita 1 — Jaringan Bantuan & Perlindungan Sosial (Bahagian 4)",
    content: "Di tempat kerja, skim perlindungan rakyat dan skim insurans sosial olehPERKESO digerakkan berasaskan caruman bulanan dan menyediakan faedahpengangguran kepada pekerja terkesan."
  },
  {
    id: 327,
    title: "Cerita 2 — Persaraan, Pencen & KWSP (Bahagian 1)",
    content: "Bagi penjawat yang menamatkan khidmat, pencen pesara diagih sebagaibayaran pencen di bawah skim pencenuntuk pesara kerajaan dan pesara tentera."
  },
  {
    id: 328,
    title: "Cerita 2 — Persaraan, Pencen & KWSP (Bahagian 2)",
    content: "Di sektor swasta, pekerja memilih skim persaraan swasta atau menyimpan dalamKWSP melalui akaun simpanan KWSP; ketika perlu, pengeluaran KWSP dibenarkan,namun fokus kekal pada simpanan hari tua yang mampan."
  },
  {
    id: 329,
    title: "Cerita 3 — Pelaburan Persaraan & Syariah (Bahagian 1)",
    content: "Agensi nasihat menawarkan pelaburan persaraan dengan menilai kadar dividen,keuntungan tahunan, dan menerbitkan laporan pelaburan."
  },
  {
    id: 330,
    title: "Cerita 3 — Pelaburan Persaraan & Syariah (Bahagian 2)",
    content: "Mereka menggubal strategi pelaburan merentasi pelaburan hartanah, pelaburansaham, dan pelaburan bon, termasuk pelaburan patuh syariah melalui dana amanah danunit amanah."
  },
  {
    id: 331,
    title: "Cerita 3 — Pelaburan Persaraan & Syariah (Bahagian 3)",
    content: "Seorang pengurus dana membentuk portfolio pelaburan yang menimbang risikopelaburan berbanding pulangan pelaburan demi kestabilan jangka panjang."
  },
  {
    id: 332,
    title: "Cerita 4 — Pasaran Modal & Isyarat Ekonomi (Bahagian 1)",
    content: "Di Bursa Malaysia, aktiviti pasaran saham dipandu indeks komposit dan prestasisaham syarikat; peniaga menjalankan perdagangan harian manakala pelabur individu danpelabur institusi meneliti laporan kewangan suku tahunan, penyata pendapatan, nisbahkeuntungan, dan kadar pertumbuhan."
  },
  {
    id: 333,
    title: "Cerita 4 — Pasaran Modal & Isyarat Ekonomi (Bahagian 2)",
    content: "Penganalisis menerbitkan ramalan ekonomi, unjuran pasaran, serta mentafsirdata ekonomi seperti inflasi, kadar inflasi, kenaikan harga, dan kesan kepada kos sarahidup."
  },
  {
    id: 334,
    title: "Cerita 4 — Pasaran Modal & Isyarat Ekonomi (Bahagian 3)",
    content: "Bank pusat mengurus kadar faedah melalui dasar monetari, sementara kerajaanmenyusun dasar fiskal, bajet tahunan, dan Belanjawan Negara di bawah Menteri Kewanganserta Kementerian Kewangan."
  },
  {
    id: 335,
    title: "Cerita 5 — Cukai & Pematuhan Digital (Bahagian 1)",
    content: "Hasil negara disokong Lembaga Hasil Dalam Negeri melalui kutipan cukai seperticukai individu, cukai korporat, dan cukai jualan dan perkhidmatan (SST), di samping dutiimport, duti eksport, cukai tanah, dan cukai pintu."
  },
  {
    id: 336,
    title: "Cerita 5 — Cukai & Pematuhan Digital (Bahagian 2)",
    content: "Perniagaan menilai pengecualian cukai, insentif pelaburan, potongan cukai, sertapelepasan cukai."
  }
]
