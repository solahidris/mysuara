export const batch6Stories = [
  {
    id: 241,
    title: "Cerita 8 — Belia, Kepimpinan & Keusahawanan (Bahagian 2)",
    content: "Agenda pembangunan belia menekankan program kepimpinandan latihankepimpinan dibantu mentor belia."
  },
  {
    id: 242,
    title: "Cerita 8 — Belia, Kepimpinan & Keusahawanan (Bahagian 3)",
    content: "Di sekolah dan kolej, aktiviti kokurikulum dalam kelab dan persatuan meriah:pengakap, pandu puteri, kadet polis, bomba sukarela, kadet tentera, kelab bahasa, kelabsains, kelab komputer, kelab debat, dan kelab inovasi."
  },
  {
    id: 243,
    title: "Cerita 8 — Belia, Kepimpinan & Keusahawanan (Bahagian 4)",
    content: "Mereka menyertai pertandingan pidato, pertandingan inovasi, pertandinganrobotik, pertandingan sains, pertandingan matematik, olimpiad sains, olimpiad matematik,serta pertandingan sukan seperti kejohanan bola sepak, kejohanan badminton, kejohananbola jaring, dan kejohanan olahraga; pemenang menerima anugerah pelajar."
  },
  {
    id: 244,
    title: "Cerita 9 — Puncak Akademik & Jaringan Alumni (Bahagian 1)",
    content: "Universiti menganjurkan majlis graduasi dan konvokesyen di dewan universiti."
  },
  {
    id: 245,
    title: "Cerita 9 — Puncak Akademik & Jaringan Alumni (Bahagian 2)",
    content: "Graduan mengenakan pakaian akademik, topi mortar, menerima skrol dan sijilpenghargaan."
  },
  {
    id: 246,
    title: "Cerita 9 — Puncak Akademik & Jaringan Alumni (Bahagian 3)",
    content: "Ucapan perasmian membuka acara sebelum perarakan graduan."
  },
  {
    id: 247,
    title: "Cerita 9 — Puncak Akademik & Jaringan Alumni (Bahagian 4)",
    content: "Malamnya ada sambutan keluarga dan majlis makan malam."
  },
  {
    id: 248,
    title: "Cerita 9 — Puncak Akademik & Jaringan Alumni (Bahagian 5)",
    content: "Ikatan kekal melalui alumni universiti, persatuan alumni, dan jaringan profesionaluntuk peluang karier."
  },
  {
    id: 249,
    title: "Cerita 10 — Luncur Kerjaya & Faedah Pekerjaan (Bahagian 1)",
    content: "Untuk kerjaya graduan, mereka melayari portal pekerjaan, menghadiri temudugamaya dan temu duga berpanel, menghantar resume digital dan portfolio profesional,mengemas kini LinkedIn serta profil profesional."
  },
  {
    id: 250,
    title: "Cerita 10 — Luncur Kerjaya & Faedah Pekerjaan (Bahagian 2)",
    content: "Majikan meminta pengesyoran dan rujukan pekerjaan sebelum mengeluarkansurat tawaran serta kontrak perkhidmatan."
  },
  {
    id: 251,
    title: "Cerita 10 — Luncur Kerjaya & Faedah Pekerjaan (Bahagian 3)",
    content: "Pekerja menerima gaji permulaan, elaun perjalanan, elaun makan, faedahperubatan, dan insurans pekerja."
  },
  {
    id: 252,
    title: "Cerita 10 — Luncur Kerjaya & Faedah Pekerjaan (Bahagian 4)",
    content: "Hak cuti termasuk cuti tahunan, cuti bersalin, cuti kecemasan, dan cuti gantian."
  },
  {
    id: 253,
    title: "Cerita 10 — Luncur Kerjaya & Faedah Pekerjaan (Bahagian 5)",
    content: "Prestasi dinilai melalui penilaian tahunan, didokumenkan dalam laporan prestasi,dan membuka jalan kepada kenaikan pangkat."
  },
  {
    id: 254,
    title: "Cerita 1 — Tadbir Urus & Ganjaran (Bahagian 1)",
    content: "Syarikat melaksana promosi dalaman berasaskan nilai korporat, integritiorganisasi, dan etika profesional."
  },
  {
    id: 255,
    title: "Cerita 1 — Tadbir Urus & Ganjaran (Bahagian 2)",
    content: "Warga cemerlang diraikan melalui anugerah prestasi, bonus tahunan, bayaraninsentif, imbuhan khas, dan program pengiktirafan yang diselaraskan dengantanggungjawab sosial korporat (CSR)."
  },
  {
    id: 256,
    title: "Cerita 1 — Tadbir Urus & Ganjaran (Bahagian 3)",
    content: "Laporan tahunan merangkumi laporan kewangan, penyata akaun, penyatauntung rugi, dan penyata imbangan, disahkan oleh audit dalamanserta audit luaran denganlampiran laporan pematuhan."
  },
  {
    id: 257,
    title: "Cerita 1 — Tadbir Urus & Ganjaran (Bahagian 4)",
    content: "Di bawah tadbir urus korporat, lembaga pengarahdipengerusikan pengerusilembaga, disokong pengarah urusan, ketua pegawai eksekutif (CEO), COO, CFO, dan CIOuntuk memastikan keputusan beretika dan telus."
  },
  {
    id: 258,
    title: "Cerita 2 — Struktur Tenaga Kerja (Bahagian 1)",
    content: "Bahagian HR diterajui ketua pegawai sumber manusia yang menyelaras ketuajabatan, eksekutif kanan, penolong pengurus, dan penyelia kanan."
  },
  {
    id: 259,
    title: "Cerita 2 — Struktur Tenaga Kerja (Bahagian 2)",
    content: "Laluan bakat dibuka kepada pelatih eksekutif, manakala ops harian digerakkanpekerja kontrak, pekerja sambilan, dan pekerja tetap."
  },
  {
    id: 260,
    title: "Cerita 2 — Struktur Tenaga Kerja (Bahagian 3)",
    content: "Sokongan operasi merangkumi staf pentadbiran, pembantu operasi, pemandusyarikat, pengawal keselamatan, dan penyambut tetamu yang menjaga imej korporat dibarisan hadapan."
  },
  {
    id: 261,
    title: "Cerita 3 — Pasukan Kreatif & Perundangan (Bahagian 1)",
    content: "Jentera komunikasi menggabungkan juruteknik IT, pentadbir sistem, pembangunlaman web, pereka grafik, pereka kandungan, juruvideo, jurugambar, editor video, danpenulis kandungan."
  },
  {
    id: 262,
    title: "Cerita 3 — Pasukan Kreatif & Perundangan (Bahagian 2)",
    content: "Pemasaran dipacu pengurus media sosial, pengurus pemasaran, pengurusjualan, jurujual, serta penyelaras projek."
  },
  {
    id: 263,
    title: "Cerita 3 — Pasukan Kreatif & Perundangan (Bahagian 3)",
    content: "Sokongan polisi dan tadbir dibantu pegawai komunikasi, pegawaiundang-undang, pegawai kewangan, pegawai sumber manusia, pegawai latihan, pegawaipenyelidikan, pegawai dasar, pegawai pembangunan, pegawai tadbir, pegawai khidmatpelanggan, dan pegawai hubungan awam."
  },
  {
    id: 264,
    title: "Cerita 3 — Pasukan Kreatif & Perundangan (Bahagian 4)",
    content: "Kewibawaan kewangan serta reputasi diperkukuh juruaudit, perundingkewangan, penasihat undang-undang, penasihat pelaburan, penasihat strategik, perundingkomunikasi, jurucakap rasmi, dan wakil media."
  },
  {
    id: 265,
    title: "Cerita 4 — Data, Kejuruteraan & AI (Bahagian 1)",
    content: "Untuk skala digital, organisasi menempatkan penganalisis data, penganalisispasaran, penganalisis polisi, penganalisis ekonomi, penganalisis risiko, dan penganalisiskeselamatan."
  },
  {
    id: 266,
    title: "Cerita 4 — Data, Kejuruteraan & AI (Bahagian 2)",
    content: "Infrastruktur disokong juruteknik rangkaian, jurutera perisian, jurutera sistem,jurutera data, saintis data, pembangun aplikasi, dan pengatur cara."
  },
  {
    id: 267,
    title: "Cerita 4 — Data, Kejuruteraan & AI (Bahagian 3)",
    content: "Aspek keselamatan dan automasi dipimpin pakar IT, pakar siber, pakarkeselamatan data, pakar AI, pakar automasi, serta pengalaman pengguna oleh pakar UX/UI,pereka pengalaman pengguna, dan pereka antaramuka pengguna."
  },
  {
    id: 268,
    title: "Cerita 4 — Data, Kejuruteraan & AI (Bahagian 4)",
    content: "Frontier diteroka jurutera AI, jurutera robotik, penyelidik AI, dan penyelidikteknologi dalam projek teknologi, inovasi digital, pembangunan sistem, dan penyelesaianpintar."
  },
  {
    id: 269,
    title: "Cerita 5 — Kerajaan Digital & Data (Bahagian 1)",
    content: "Agenda kerajaan digital mempercepat transformasi sektor awam melalui sistemmaklumat kerajaan dan pangkalan data nasional yang disepadukan dengan MyDigital ID."
  },
  {
    id: 270,
    title: "Cerita 5 — Kerajaan Digital & Data (Bahagian 2)",
    content: "Keutamaan keselamatan siber kerajaan serta privasi rakyat digabung dengandata terbuka kerajaan dan pelan strategik digital untuk merancakkan ekonomi berasaskandata dan AI untuk kerajaan."
  },
  {
    id: 271,
    title: "Cerita 5 — Kerajaan Digital & Data (Bahagian 3)",
    content: "Automasi seperti automasi pentadbiran dan chatbot kerajaan dipaparkan di portalrasmi kerajaan dan laman sesawang kementerian."
  },
  {
    id: 272,
    title: "Cerita 5 — Kerajaan Digital & Data (Bahagian 4)",
    content: "Setiap inisiatif diiringi pengumuman rasmi, siaran media kerajaan, kenyataanakhbar, dan kenyataan dasar dalam kerangka pelan tindakan nasional."
  },
  {
    id: 273,
    title: "Cerita 6 — Payung Dasar Nasional (Bahagian 1)",
    content: "Negara menyelaras dasar transformasi ekonomi, dasar pembangunan negara,dasar tenaga nasional, dasar keselamatan makanan, dasar perindustrian, dasar inovasi,serta dasar sains dan teknologi."
  },
  {
    id: 274,
    title: "Cerita 6 — Payung Dasar Nasional (Bahagian 2)",
    content: "Tumpuan hijau diperkukuh oleh dasar tenaga boleh baharu, dasar digital, dasardata terbuka, dan dasar privasi nasional."
  },
  {
    id: 275,
    title: "Cerita 6 — Payung Dasar Nasional (Bahagian 3)",
    content: "Arah industri ditetapkan oleh pelan induk industri, rancangan pembangunan limatahun, dan rancangan jangka panjang yang realistik."
  },
  {
    id: 276,
    title: "Cerita 7 — Kelestarian & Tenaga Rendah Karbon (Bahagian 1)",
    content: "Korporat melancarkan pelan tindakan hijau dan strategi kelestarian berasaskandasar karbon rendah, memacu ekonomi hijau dan ekonomi sirkular."
  },
  {
    id: 277,
    title: "Cerita 7 — Kelestarian & Tenaga Rendah Karbon (Bahagian 2)",
    content: "Mereka beralih kepada tenaga bersih untuk mencapai neutraliti karbonsejajarpembangunan lestari."
  },
  {
    id: 278,
    title: "Cerita 7 — Kelestarian & Tenaga Rendah Karbon (Bahagian 3)",
    content: "Melalui kempen hijau, gerakan alam sekitar, aktivis hijau, dan NGO alam sekitar,syarikat menyokong projek konservasi, pemuliharaan hutan, pemeliharaan sungai, kempenpembersihan, serta penanaman pokok."
  },
  {
    id: 279,
    title: "Cerita 7 — Kelestarian & Tenaga Rendah Karbon (Bahagian 4)",
    content: "Di komuniti, inisiatif komuniti hijau, kelab alam sekitar, sekolah lestari, danpendidikan hijau memupuk budaya lestari."
  },
  {
    id: 280,
    title: "Cerita 8 — Tenaga Baharu & Mobiliti Bandar (Bahagian 1)",
    content: "R&D menumpu inovasi tenaga, teknologi rendah karbon, penyelidikan tenaga,dan skala tenaga boleh baharuyang disokong penyimpanan tenaga serta grid tenaga pintar."
  },
  {
    id: 281,
    title: "Cerita 8 — Tenaga Baharu & Mobiliti Bandar (Bahagian 2)",
    content: "Pengangkutan memeluk kenderaan elektrik sebagai pengangkutan hijau untukmobiliti bandar; armada bas elektrik dan motosikal elektrik disokong stesen pengecas EV,subsidi EV, serta insentif hijau."
  },
  {
    id: 282,
    title: "Cerita 8 — Tenaga Baharu & Mobiliti Bandar (Bahagian 3)",
    content: "Kerajaan memperkenal cukai karbon, dasar pengurangan pelepasan,mewajibkan laporan karbon, pengauditan karbon, dan mengukur jejak karbon demipengurangan gas rumah hijau."
  },
  {
    id: 283,
    title: "Cerita 8 — Tenaga Baharu & Mobiliti Bandar (Bahagian 4)",
    content: "Arah daya tahan iklim diterjemah dalam pelan mitigasi iklim dan pelan adaptasiiklim."
  },
  {
    id: 284,
    title: "Cerita 9 — Kesiapsiagaan & Bantuan (Bahagian 1)",
    content: "Tatkala bencana alam melanda, rangka pengurusan bencana mengaktifkankesiapsiagaan bencana, latihan kecemasan, dan bantuan kemanusiaan melalui tabungbencana."
  },
  {
    id: 285,
    title: "Cerita 9 — Kesiapsiagaan & Bantuan (Bahagian 2)",
    content: "Ribuan sukarelawan bencana berganding bahu dengan penyelamat untukoperasi mencari dan menyelamat dalam misi bantuan."
  },
  {
    id: 286,
    title: "Cerita 9 — Kesiapsiagaan & Bantuan (Bahagian 3)",
    content: "Mangsa ditempatkan di pusat pemindahan sambil menerima bantuan kecemasandan pelan pasca pemulihan melalui dana sokongan."
  },
  {
    id: 287,
    title: "Cerita 9 — Kesiapsiagaan & Bantuan (Bahagian 4)",
    content: "Selepas krisis, agensi menghasilkan laporan bencana, menjalankan penilaianrisiko, menyusun strategi pemulihan, dan menguatkan ketahanan komuniti."
  },
  {
    id: 288,
    title: "Cerita 10 — Menghubungkan Semua Benang Merah (Bahagian 1)",
    content: "Di mesyuarat lembaga, CEO, COO, CFO, dan CIO menilai kemajuan projekteknologi hijau yang menyokong dasar inovasi serta ekonomi berasaskan data."
  }
]
