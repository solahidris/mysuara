export const batch15Stories = [
  {
    id: 673,
    title: "Cerita 7 — PRK Kampus (Bahagian 2)",
    content: "Hari mengundi berlangsung teratur; pusat mengundi dilengkapi pengimbas kad.Keputusan diumum, calon menang berjanji laporan 100 hari: KPI, projek kecil, dankonsultasi berkala."
  },
  {
    id: 674,
    title: "Cerita 7 — PRK Kampus (Bahagian 3)",
    content: "“Demokrasi bermula di sini,” kata rektor, “dengan warganegara muda yang beranibertanya dan bersedia menanggung akibat keputusan bersama.”"
  },
  {
    id: 675,
    title: "Cerita 8 — Koperasi Tani (Bahagian 1)",
    content: "Di bengkel koperasi tani, nelayan dan petani belajar pemasaran digital. Merekamempelajari platform e-dagang, foto produk, dan penulisan kapsyen. FAMA, RISDA, danMARDI berkongsi geran, standard, dan logistik."
  },
  {
    id: 676,
    title: "Cerita 8 — Koperasi Tani (Bahagian 2)",
    content: "Seorang pakcik menunjukkan cendol istimewa; seorang makcik mempromosisambal belacan. Latihan mengupas kos, margin, serta inventori."
  },
  {
    id: 677,
    title: "Cerita 8 — Koperasi Tani (Bahagian 3)",
    content: "Setelah sebulan, jualan meningkat; ulasan bintang membawa pelanggan setia.“Kekuatan kita ialah kolaborasi,” kata fasilitator, “dan data—setiap keputusan dimaklumkanoleh fakta.” Mereka pulang dengan semangat baharu, melihat pasaran bukan lagi jauh,tetapi di hujung telefon."
  },
  {
    id: 678,
    title: "Cerita 9 — Tapak Pembinaan (Bahagian 1)",
    content: "Syarikat pembinaan mengadakan taklimat keselamatan: PPE, tali pinggang, danprosedur kecemasan. Jurutera awam menerangkan pelan struktur, sistem saliran, dan auditkualiti. Penjaga stor menyemak bahan binaan: simen, keluli, kaca, jubin."
  },
  {
    id: 679,
    title: "Cerita 9 — Tapak Pembinaan (Bahagian 2)",
    content: "Pengurus tapak mengemas kini perisian jadual, mengesan kelewatan dan risiko.Di lawatan majlis perbandaran, pelan bangunan, lesen, serta pematuhan diperiksa.Kontraktor menunjukkan penambahbaikan: pengurangan sisa, kitar semula, dan kawalanhabuk."
  },
  {
    id: 680,
    title: "Cerita 9 — Tapak Pembinaan (Bahagian 3)",
    content: "Projek siap; penyerahan kunci berlangsung dengan sijil kelulusan. Pendudukmasuk rumah baharu—bukti bahawa disiplin proses menghasilkan ruang hidup yangselamat."
  },
  {
    id: 681,
    title: "Cerita 10 — Sarang Startup (Bahagian 1)",
    content: "Ruang kerja bersama menjadi sarang startup: fintech, edtech, govtech. Penasihatstrategik mengajar model perniagaan, unit ekonomi, dan jalur pertumbuhan. Pasukanproduk mengutamakan masalah sebenar, bukan fesyen teknologi."
  },
  {
    id: 682,
    title: "Cerita 10 — Sarang Startup (Bahagian 2)",
    content: "Mereka menguji MVP, membaca maklum balas, dan mengulang cepat. Danapermulaan datang dengan syarat tadbir urus. “Jangan kejar vanity metrics,” pesan mentor,“kejar kepuasan pelanggan.”"
  },
  {
    id: 683,
    title: "Cerita 10 — Sarang Startup (Bahagian 3)",
    content: "Pada demo day, pembentang menunjukkan traction, kos pemerolehan, danpulangan seumur hidup. Pelabur bertanya tentang risiko peraturan; pengasas menjawabdengan pelan pematuhan. Tepukan bergema—bukan kerana janji kosong, tetapi keranakejujuran data."
  },
  {
    id: 684,
    title: "Cerita 1 — Teater & Kebebasan Bersuara (Bahagian 1)",
    content: "Di balai seni, pementasan teater tentang kebebasan bersuara menggabungkanmuzik, sajak, dan drama dokumentari. Penulis naskhah merujuk undang-undangkomunikasi, etika kewartawanan, dan kes mahkamah."
  },
  {
    id: 685,
    title: "Cerita 1 — Teater & Kebebasan Bersuara (Bahagian 2)",
    content: "Penonton mengisi borang soal selidik; ulasan menyarankan bahagian forumdiperpanjang. Media menerbitkan rencana; pengulas memuji keberanian, menegurbeberapa kelemahan teknikal."
  },
  {
    id: 686,
    title: "Cerita 1 — Teater & Kebebasan Bersuara (Bahagian 3)",
    content: "Kumpulan produksi mengadakan sesi “sesi soal jawab” selepas persembahan,menjelaskan sumber dan metod. “Seni membantu masyarakat memahami kompleksiti,” katapengarah. Di pintu keluar, risalah literasi media diagih; harapan mereka sederhana—lebihramai menjadi pembaca yang teliti, pendengar yang adil."
  },
  {
    id: 687,
    title: "Cerita 2 — Sukan Komuniti (Bahagian 1)",
    content: "Program kesukanan komuniti memperkenalkan bola jaring, badminton, danlarian. Jurulatih menekankan kecergasan, ketahanan, dan disiplin. Pasukan merancangjadual latihan, nutrisi, dan rehat."
  },
  {
    id: 688,
    title: "Cerita 2 — Sukan Komuniti (Bahagian 2)",
    content: "Skor awal mengecewakan, namun semangat berpasukan tumbuh.Penonton—jiran, rakan, keluarga—memberi sorakan. Jawatankuasa menganjurkankejohanan kecil; hadiah tidak mahal, tetapi maruah tinggi."
  },
  {
    id: 689,
    title: "Cerita 2 — Sukan Komuniti (Bahagian 3)",
    content: "Seorang pemain menulis di profil media sosial: “Kami belajar kalah denganbermaruah dan menang tanpa lupa asal.” Di penutup, pengadil menyampaikan nasihat:sukan adalah sekolah karakter, tempat kita belajar mengurus emosi sambil mengejarkejayaan."
  },
  {
    id: 690,
    title: "Cerita 3 — Kelas Bahasa (Bahagian 1)",
    content: "Di kelas bahasa, cikgu mengajar perbendaharaan kata harian—makanan,pengangkutan, pejabat. Pelajar menulis cerpen pendek, menyelit istilah teknologi: e-mel,kata laluan, privasi, penipuan dalam talian. Mereka melakar peta bandar, menyebut jalan,stesen, dan destinasi."
  },
  {
    id: 691,
    title: "Cerita 3 — Kelas Bahasa (Bahagian 2)",
    content: "Latihan dialog di kaunter tiket melatih sopan santun. Cikgu menyemaktatabahasa, menasihati ringkas: “Kejelasan diutamakan.” Pada akhir semester, ujian lisandijalankan; beberapa pelajar gugup, namun rakan menyokong."
  },
  {
    id: 692,
    title: "Cerita 3 — Kelas Bahasa (Bahagian 3)",
    content: "Keputusan memuaskan; kelas bergambar kenangan. “Bahasa ialah jambatan,”kata cikgu, “yang menghubungkan manusia, budaya, dan masa depan pekerjaan.”"
  },
  {
    id: 693,
    title: "Cerita 4 — Kualiti Hospital (Bahagian 1)",
    content: "Sebuah hospital daerah menubuhkan pasukan kualiti. Mereka menilai prosespendaftaran, triage, dan farmasi. Masa menunggu dikurang melalui pengagihan tugas dansistem nombor pintar."
  },
  {
    id: 694,
    title: "Cerita 4 — Kualiti Hospital (Bahagian 2)",
    content: "Doktor membincang garis panduan klinikal; jururawat menstandardkan serahanbertulis. Pesakit mengisi borang maklum balas; aduan ditangani secara telus. Keselamatandata kesihatan diperkukuh dengan penyulitan dan kawalan akses."
  },
  {
    id: 695,
    title: "Cerita 4 — Kualiti Hospital (Bahagian 3)",
    content: "Dalam audit, skor meningkat; anugerah perkhidmatan diberi. Pengarah hospitalmenegaskan kemanusiaan: “Statistik penting, namun empati yang menyembuhkan.” Poster“senyum, sapa, salam” dilekatkan—kecil tetapi bererti dalam hektiknya rawatan harian."
  },
  {
    id: 696,
    title: "Cerita 5 — Biodiversiti Borneo (Bahagian 1)",
    content: "Di kampus Borneo, penyelidik mengkaji biodiversiti hutan, memantau hidupanmarin, dan menilai terumbu karang. Mereka bekerjasama dengan taman hidupan liar,komuniti nelayan, dan sekolah."
  },
  {
    id: 697,
    title: "Cerita 5 — Biodiversiti Borneo (Bahagian 2)",
    content: "Data dikongsi terbuka; pelajar menulis rencana popular sains. Kempenpendidikan hijau menemui kanak-kanak: permainan kitar semula, komik karbon, dan lawatansungai. Laporan cadangan menekankan konservasi, ekonomi sirkular, serta insentif hijau."
  },
  {
    id: 698,
    title: "Cerita 5 — Biodiversiti Borneo (Bahagian 3)",
    content: "Di majlis pelancaran, wakil kerajaan berjanji dana dan standard pensijilan.“Kelestarian,” ucap ketua projek, “bukan slogan—ia disiplin harian yang menuntutkeberanian menghadapi kompromi sukar.”"
  },
  {
    id: 699,
    title: "Cerita 6 — Firma Undang-Undang Teknologi (Bahagian 1)",
    content: "Sebuah firma undang-undang muda mengkhusus data, harta intelek, danteknologi kewangan. Peguam menyemak kontrak, paten, serta tanda dagangan. Klienstartup memerlukan polisi privasi dan terma perkhidmatan."
  },
  {
    id: 700,
    title: "Cerita 6 — Firma Undang-Undang Teknologi (Bahagian 2)",
    content: "Firma menerangkan PDPA, penguatkuasaan, dan risiko litigasi. Di mahkamah,mereka berhujah dengan bukti dokumentari dan keterangan saksi. Selepas keputusan, firmamenulis ulasan, mengajar komuniti tentang hak pengguna."
  },
  {
    id: 701,
    title: "Cerita 6 — Firma Undang-Undang Teknologi (Bahagian 3)",
    content: "“Akses kepada keadilan,” kata rakan kongsi, “bermula dengan bahasa yangterang.” Reputasi firma meningkat bukan kerana gimik, tetapi kerana integriti dan kerja telitiyang konsisten."
  },
  {
    id: 702,
    title: "Cerita 7 — Ladang Moden & Koperasi (Bahagian 1)",
    content: "Di ladang moden, dron pertanian memantau tanaman padi. Sensor mengukurkelembapan; sistem pengairan automatik menjimatkan air. Baja organik dan kawalan biologimengurang racun."
  },
  {
    id: 703,
    title: "Cerita 7 — Ladang Moden & Koperasi (Bahagian 2)",
    content: "Koperasi petani berkongsi mesin, menawar harga input, dan menguruspemasaran hasil tani. Fasilitator mengajar akaun bank, e-dompet, dan pinjaman mikro. Jetinelayan berdekatan menjadi hab dagang kecil pada hujung minggu."
  },
  {
    id: 704,
    title: "Cerita 7 — Ladang Moden & Koperasi (Bahagian 3)",
    content: "“Ekonomi desa bukan ketinggalan,” kata ketua koperasi, “ia berubah bersamadata.” Laporan sukuan menunjukkan pendapatan naik, hutang berkurang, dan dana komunitibertambah untuk biasiswa pelajar."
  },
  {
    id: 705,
    title: "Cerita 8 — Studio Rakaman Komuniti (Bahagian 1)",
    content: "Studio rakaman komuniti membuka ruang untuk muzik, podcast, dan kandunganpendidikan. Pengurus media sosial melatih pencipta tentang hak cipta, lesen, dan etika.Mereka mempelajari mikrofon, pengeditan, dan kapsyen boleh akses."
  },
  {
    id: 706,
    title: "Cerita 8 — Studio Rakaman Komuniti (Bahagian 2)",
    content: "Topik hangat: kesihatan mental, pekerjaan, dan literasi digital. Data analitikmenunjukkan kadar tontonan stabil; kolaborasi silang menaikkan pengikut. Penaja kecilhadir, tetapi syarat telus."
  },
  {
    id: 707,
    title: "Cerita 8 — Studio Rakaman Komuniti (Bahagian 3)",
    content: "“Kandungan yang baik,” kata editor, “ialah gabungan cerita jujur dan kualititeknikal.” Pada anugerah tahunan, mereka tidak menang semua, namun jaringan yangdibina itulah trofi sebenar."
  },
  {
    id: 708,
    title: "Cerita 9 — Pelancongan Komuniti (Bahagian 1)",
    content: "Pelancongan komuniti memperkenal homestay, warisan seni bina, dan makanantradisional. Pemandu pelancong bercerita tentang mercu tanda, muzium, dan tapakbersejarah. Pelawat belajar membuat laksa, menumbuk sambal, dan menyeduh teh tarik."
  },
  {
    id: 709,
    title: "Cerita 9 — Pelancongan Komuniti (Bahagian 2)",
    content: "Aplikasi memudahkan tempahan; ulasan mengangkat reputasi kampung. Hasildibahagi adil; sebahagian untuk dana kebersihan dan lampu jalan. “Pelancongan lestari,”kata pengurus, “melindungi alam sambil memakmurkan rakyat.”"
  },
  {
    id: 710,
    title: "Cerita 9 — Pelancongan Komuniti (Bahagian 3)",
    content: "Di akhir lawatan, tetamu menulis kad ucapan, memuat naik gambar, dan berjanjikembali. Sebuah tempat kecil bertukar besar dalam memori ramai."
  },
  {
    id: 711,
    title: "Cerita 10 — Makmal Siber & Insiden (Bahagian 1)",
    content: "Di makmal siber, pasukan respons memerangi perisian hasad. Merekamengaudit sistem, tampal kerentanan, dan melatih kakitangan tentang pautan palsu. Insidendilapor segera; log dianalisis."
  },
  {
    id: 712,
    title: "Cerita 10 — Makmal Siber & Insiden (Bahagian 2)",
    content: "Ketua keselamatan menulis kenyataan media jujur, menangkis spekulasi. Polisikata laluan, pengesahan dua faktor, dan sandaran diuji berkala. Kerjasama dengan agensinasional mempercepat siasatan."
  },
  {
    id: 713,
    title: "Cerita 10 — Makmal Siber & Insiden (Bahagian 3)",
    content: "“Tiada keselamatan mutlak,” katanya, “cuma pengurusan risiko matang.” Selepaskrisis, organisasi menerbitkan pelajaran teras dan pelan peningkatan. Kepercayaanpengguna pulih kerana ketelusan, bukan kerana menafikan hakikat ancaman."
  },
  {
    id: 714,
    title: "Cerita 1 — Meja Bantuan Daerah (Bahagian 1)",
    content: "Di pejabat daerah, meja bantuan pelanggan diperkemas. Sistem tiket merekodaduan; SLA dipantau. Pegawai menyiapkan skrip panggilan dan panduan FAQ."
  },
  {
    id: 715,
    title: "Cerita 1 — Meja Bantuan Daerah (Bahagian 2)",
    content: "Sidang media mingguan mengumumkan kemajuan—jalan dibaiki, lampudiperbaiki, longkang dibersih. Komuniti menghargai respons pantas; saluran aduan rasmimengurang rungutan di media sosial. Pengerusi majlis menekankan budaya perkhidmatan:senyum, jelas, bertanggungjawab."
  },
  {
    id: 716,
    title: "Cerita 1 — Meja Bantuan Daerah (Bahagian 3)",
    content: "“Rakyat bukan beban,” katanya, “mereka tujuan.” Di papan kenyataan, indikatorprestasi dipamer—simbol kecil bahawa kerajaan tempatan juga boleh belajar, berubah, danmaju."
  },
  {
    id: 717,
    title: "Cerita 2 — Keusahawanan Wanita (Bahagian 1)",
    content: "Kelas keusahawanan wanita mempertemu ibu muda, graduan, dan pekerjasambilan. Mereka belajar pelan pemasaran, jenama, dan foto produk. Modul literasikewangan menerangkan aliran tunai, harga, dan dividen. Mentor berkongsi kisah gagal danbangkit."
  },
  {
    id: 718,
    title: "Cerita 2 — Keusahawanan Wanita (Bahagian 2)",
    content: "Peserta melancar perniagaan mikro—kuih, pakaian, penjagaan rumah—melaluimarketplace dan media sosial. Sokongan moral jadi bahan bakar; kumpulan WhatsAppmenjadi talian hayat. “Kami tidak mahu belas kasihan,” kata seorang peserta, “kami mahupeluang adil.”"
  },
  {
    id: 719,
    title: "Cerita 2 — Keusahawanan Wanita (Bahagian 3)",
    content: "Selepas tiga bulan, puluhan akaun jualan aktif; beberapa mendapat penajaankecil."
  },
  {
    id: 720,
    title: "Cerita 3 — Kelas Sivik & Undi18 (Bahagian 1)",
    content: "Dalam kelas sivik, guru membincang Undi18, daftar pemilih, dan tanggungjawabwarganegara. Pelajar meneliti manifest o parti, menyoal janji realistik. Mereka membandingdata, mengesan berita palsu, dan mempraktik semakan fakta."
  }
]
